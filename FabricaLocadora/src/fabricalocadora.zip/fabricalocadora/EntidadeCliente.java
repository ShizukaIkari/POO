/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fabricalocadora;

/**
 *
 * @author Serenna
 */
public class EntidadeCliente {
    private String nome;
    private String sobrenome;
    private String email;
    private String nascimento;
    
}
