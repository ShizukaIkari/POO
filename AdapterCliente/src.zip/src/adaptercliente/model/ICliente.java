package adaptercliente.model;

public interface ICliente {

    public String getNomeCompleto();

    public void setNomeCompleto(String nomeCompleto);

    public String getTelefone();

    public void setTelefone(String telefone);

    public String getEmail();

    public void setEmail(String email);

    public String getCelular();

    public void setCelular(String celular);

}
